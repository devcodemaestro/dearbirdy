export const myBuddyMenuItems = [
  {
    text: "설정",
    icon: "/images/my-buddy/setup.svg",
    route: "/mybuddy/settings",
  },
  { text: "FAQ", icon: "/images/my-buddy/faq.svg", route: "/mybuddy/faq" },
  {
    text: "마이 버디 새롭게 찾기",
    icon: "/images/my-buddy/find.svg",
    route: "/mybuddy/find-buddy",
  },
  {
    text: "버디 유형 모두 보기",
    icon: "/images/my-buddy/types.svg",
    route: "/mybuddy/all-buddy-types",
  },
];
