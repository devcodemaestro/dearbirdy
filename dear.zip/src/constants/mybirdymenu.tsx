export const myBirdyMenuItems = [
  {
    text: "설정",
    icon: "/images/my-birdy/setup.svg",
    route: "/mybirdy/settings",
  },
  { text: "FAQ", icon: "/images/my-birdy/faq.svg", route: "/mybirdy/faq" },
  {
    text: "마이 버디 새롭게 찾기",
    icon: "/images/my-birdy/find.svg",
    route: "/mybirdy/find-birdy",
  },
  {
    text: "버디 유형 모두 보기",
    icon: "/images/my-birdy/types.svg",
    route: "/mybirdy/all-birdy-types",
  },
];
