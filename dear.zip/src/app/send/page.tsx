import React from "react";

const SendPage: React.FC = () => {
  return <div></div>;
};

export default SendPage;
