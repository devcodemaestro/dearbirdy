import LetterOpen from "@/components/letter/LetterOpen";
import React from "react";

const LetterOpenPage: React.FC = () => {
  return <LetterOpen />;
};

export default LetterOpenPage;
