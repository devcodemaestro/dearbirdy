import React from "react";

const LetterDetail: React.FC = () => {
  return <div>LetterDetail</div>;
};

export default LetterDetail;
