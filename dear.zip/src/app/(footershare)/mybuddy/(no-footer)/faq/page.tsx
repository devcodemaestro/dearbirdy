export default function FAQPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">FAQ</h1>
      <p>자주 묻는 질문을 확인하세요.</p>
    </div>
  );
}
