export default function AllBuddyTypesPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">버디 유형 모두 보기</h1>
      <p>모든 버디 유형을 확인해보세요.</p>
    </div>
  );
}
