"use client";

import MyBuddyIntro from "./MyBuddyIntro";

export default function MyBuddy() {
  return <MyBuddyIntro />;
}
