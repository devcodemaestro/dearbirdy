export default function NonfooterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return { children };
}
