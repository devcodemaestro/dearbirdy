export default function FindbirdyPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">마이 버디 새롭게 찾기</h1>
      <p>새로운 버디를 찾아보세요!</p>
    </div>
  );
}
